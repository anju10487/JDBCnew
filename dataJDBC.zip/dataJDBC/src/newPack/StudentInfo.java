package newPack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class StudentInfo 
	{
	void addStudent()throws Exception
		{
			try
			{
				Class.forName("org.h2.Driver");
				Connection con=DriverManager.getConnection("jdbc:h2:tep://localhost/~/jdbctest","sa","");
				PreparedStatement pst=con.prepareStatement("Insert into student values(201,'Rahul','mvm',56875");
				pst.executeUpdate();
				pst.close();
				con.close();
				System.out.println("DATA IS ADDED...");		
			}
		catch(Exception e)
			{
			System.out.println(e);
			}
	}

}
